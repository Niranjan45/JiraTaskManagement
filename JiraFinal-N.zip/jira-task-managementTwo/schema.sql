-- ============================================================
-- Jira Task Management System — Database Schema
-- Compatible with PostgreSQL 14+ and MySQL 8+
-- ============================================================

-- Create database (run as superuser)
-- CREATE DATABASE taskmanager_db;

-- ============================================================
-- TABLES
-- ============================================================

CREATE TABLE IF NOT EXISTS users (
    id          BIGSERIAL PRIMARY KEY,
    name        VARCHAR(100)  NOT NULL,
    email       VARCHAR(150)  NOT NULL UNIQUE,
    role        VARCHAR(30)   NOT NULL CHECK (role IN ('ADMIN','PROJECT_MANAGER','DEVELOPER','TESTER','VIEWER')),
    created_at  TIMESTAMP     NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMP     NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS projects (
    id              BIGSERIAL PRIMARY KEY,
    name            VARCHAR(200) NOT NULL,
    description     TEXT,
    created_by      BIGINT       NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    created_at      TIMESTAMP    NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS tasks (
    id               BIGSERIAL PRIMARY KEY,
    title            VARCHAR(300)  NOT NULL,
    description      TEXT,
    status           VARCHAR(20)   NOT NULL DEFAULT 'OPEN'
                         CHECK (status IN ('OPEN','IN_PROGRESS','BLOCKED','DONE')),
    priority         VARCHAR(20)   NOT NULL DEFAULT 'MEDIUM'
                         CHECK (priority IN ('LOW','MEDIUM','HIGH','CRITICAL')),
    assigned_user_id BIGINT        REFERENCES users(id) ON DELETE SET NULL,
    project_id       BIGINT        NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    due_date         DATE,
    created_at       TIMESTAMP     NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMP     NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS task_comments (
    id              BIGSERIAL PRIMARY KEY,
    task_id         BIGINT    NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    user_id         BIGINT    NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    comment_text    TEXT      NOT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS task_activities (
    id              BIGSERIAL PRIMARY KEY,
    task_id         BIGINT      NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    activity_type   VARCHAR(40) NOT NULL,
    old_value       VARCHAR(500),
    new_value       VARCHAR(500),
    updated_by      BIGINT      NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    timestamp       TIMESTAMP   NOT NULL DEFAULT NOW()
);

-- ============================================================
-- INDEXES
-- ============================================================

CREATE INDEX IF NOT EXISTS idx_tasks_project    ON tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_tasks_user       ON tasks(assigned_user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_status     ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_due_date   ON tasks(due_date);
CREATE INDEX IF NOT EXISTS idx_comments_task    ON task_comments(task_id);
CREATE INDEX IF NOT EXISTS idx_activities_task  ON task_activities(task_id);

-- ============================================================
-- SAMPLE DATA
-- ============================================================

INSERT INTO users (name, email, role) VALUES
  ('Alice Admin',    'alice@example.com',   'ADMIN'),
  ('Bob Manager',    'bob@example.com',     'PROJECT_MANAGER'),
  ('Charlie Dev',    'charlie@example.com', 'DEVELOPER'),
  ('Diana Dev',      'diana@example.com',   'DEVELOPER'),
  ('Eve Tester',     'eve@example.com',     'TESTER');

INSERT INTO projects (name, description, created_by) VALUES
  ('E-Commerce Platform',
   'Build a scalable e-commerce platform with microservices.',
   (SELECT id FROM users WHERE email='bob@example.com')),
  ('Mobile Banking App',
   'Cross-platform mobile banking application.',
   (SELECT id FROM users WHERE email='alice@example.com'));

INSERT INTO tasks (title, description, status, priority, assigned_user_id, project_id, due_date) VALUES
  ('Design database schema',
   'Create ERD and database schema for product, order, and user tables.',
   'DONE', 'HIGH',
   (SELECT id FROM users WHERE email='charlie@example.com'),
   (SELECT id FROM projects WHERE name='E-Commerce Platform'),
   NOW() - INTERVAL '5 days'),

  ('Implement product catalog API',
   'REST API for CRUD operations on the product catalog.',
   'IN_PROGRESS', 'HIGH',
   (SELECT id FROM users WHERE email='charlie@example.com'),
   (SELECT id FROM projects WHERE name='E-Commerce Platform'),
   NOW() + INTERVAL '3 days'),

  ('Shopping cart service',
   'Implement add/remove/update cart logic with Redis cache.',
   'OPEN', 'MEDIUM',
   (SELECT id FROM users WHERE email='diana@example.com'),
   (SELECT id FROM projects WHERE name='E-Commerce Platform'),
   NOW() + INTERVAL '7 days'),

  ('Payment gateway integration',
   'Integrate Stripe for payment processing.',
   'BLOCKED', 'CRITICAL',
   (SELECT id FROM users WHERE email='diana@example.com'),
   (SELECT id FROM projects WHERE name='E-Commerce Platform'),
   NOW() + INTERVAL '10 days'),

  ('Write integration tests for catalog API',
   'Cover all edge cases for product catalog endpoints.',
   'OPEN', 'MEDIUM',
   (SELECT id FROM users WHERE email='eve@example.com'),
   (SELECT id FROM projects WHERE name='E-Commerce Platform'),
   NOW() + INTERVAL '5 days'),

  ('Authentication module',
   'Implement biometric and PIN-based authentication.',
   'IN_PROGRESS', 'CRITICAL',
   (SELECT id FROM users WHERE email='charlie@example.com'),
   (SELECT id FROM projects WHERE name='Mobile Banking App'),
   NOW() + INTERVAL '2 days'),

  ('Fund transfer API',
   'NEFT, RTGS, IMPS transfer endpoints with transaction history.',
   'OPEN', 'HIGH',
   (SELECT id FROM users WHERE email='diana@example.com'),
   (SELECT id FROM projects WHERE name='Mobile Banking App'),
   NOW() + INTERVAL '14 days');

INSERT INTO task_comments (task_id, user_id, comment_text) VALUES
  ((SELECT id FROM tasks WHERE title='Implement product catalog API'),
   (SELECT id FROM users WHERE email='bob@example.com'),
   'Please ensure the API supports filtering by category and price range.'),

  ((SELECT id FROM tasks WHERE title='Implement product catalog API'),
   (SELECT id FROM users WHERE email='charlie@example.com'),
   'Understood. Will also add pagination and sorting support.'),

  ((SELECT id FROM tasks WHERE title='Payment gateway integration'),
   (SELECT id FROM users WHERE email='bob@example.com'),
   'Blocked because the Stripe test credentials have not been shared yet.');

INSERT INTO task_activities (task_id, activity_type, old_value, new_value, updated_by) VALUES
  ((SELECT id FROM tasks WHERE title='Design database schema'),
   'TASK_CREATED', NULL, 'OPEN',
   (SELECT id FROM users WHERE email='bob@example.com')),

  ((SELECT id FROM tasks WHERE title='Design database schema'),
   'STATUS_CHANGED', 'OPEN', 'IN_PROGRESS',
   (SELECT id FROM users WHERE email='charlie@example.com')),

  ((SELECT id FROM tasks WHERE title='Design database schema'),
   'STATUS_CHANGED', 'IN_PROGRESS', 'DONE',
   (SELECT id FROM users WHERE email='charlie@example.com'));

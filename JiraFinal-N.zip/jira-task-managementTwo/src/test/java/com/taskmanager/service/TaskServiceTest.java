package com.taskmanager.service;

import com.taskmanager.dto.request.CreateTaskRequest;
import com.taskmanager.dto.request.UpdateTaskRequest;
import com.taskmanager.dto.response.TaskResponse;
import com.taskmanager.entity.Project;
import com.taskmanager.entity.Task;
import com.taskmanager.entity.User;
import com.taskmanager.enums.TaskPriority;
import com.taskmanager.enums.TaskStatus;
import com.taskmanager.enums.UserRole;
import com.taskmanager.exception.ResourceNotFoundException;
import com.taskmanager.mapper.TaskActivityMapper;
import com.taskmanager.mapper.TaskCommentMapper;
import com.taskmanager.mapper.UserMapper;
import com.taskmanager.repository.TaskActivityRepository;
import com.taskmanager.repository.TaskCommentRepository;
import com.taskmanager.repository.TaskRepository;
import com.taskmanager.service.impl.ProjectServiceImpl;
import com.taskmanager.service.impl.TaskServiceImpl;
import com.taskmanager.service.impl.UserServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TaskServiceTest {

    @Mock private TaskRepository taskRepository;
    @Mock private TaskCommentRepository commentRepository;
    @Mock private TaskActivityRepository activityRepository;
    @Mock private UserServiceImpl userService;
    @Mock private ProjectServiceImpl projectService;
    @Mock private TaskCommentMapper commentMapper;
    @Mock private TaskActivityMapper activityMapper;
    @Mock private UserMapper userMapper;

    @InjectMocks private TaskServiceImpl taskService;

    private User user;
    private Project project;
    private Task task;

    @BeforeEach
    void setUp() {
        user = User.builder()
                .id(1L).name("Dev").email("dev@test.com").role(UserRole.DEVELOPER).build();

        project = Project.builder()
                .id(1L).name("Test Project").createdBy(user).build();

        task = Task.builder()
                .id(1L).title("Test Task").description("Desc")
                .status(TaskStatus.OPEN).priority(TaskPriority.MEDIUM)
                .project(project).assignedUser(user)
                .dueDate(LocalDate.now().plusDays(5))
                .build();
    }

    @Test
    void createTask_success() {
        CreateTaskRequest req = new CreateTaskRequest();
        req.setTitle("Test Task");
        req.setDescription("Desc");
        req.setPriority(TaskPriority.MEDIUM);
        req.setProjectId(1L);
        req.setAssignedUserId(1L);

        when(projectService.findProjectOrThrow(1L)).thenReturn(project);
        when(userService.findUserOrThrow(1L)).thenReturn(user);
        when(taskRepository.save(any(Task.class))).thenReturn(task);
        when(activityRepository.save(any())).thenReturn(null);

        TaskResponse result = taskService.createTask(req);

        assertThat(result).isNotNull();
        assertThat(result.getTitle()).isEqualTo("Test Task");
        verify(taskRepository).save(any(Task.class));
    }

    @Test
    void getTaskById_notFound_throwsException() {
        when(taskRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> taskService.getTaskById(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    void updateTask_statusChange_recordsActivity() {
        UpdateTaskRequest req = new UpdateTaskRequest();
        req.setStatus(TaskStatus.IN_PROGRESS);
        req.setUpdatedById(1L);

        when(taskRepository.findById(1L)).thenReturn(Optional.of(task));
        when(userService.findUserOrThrow(1L)).thenReturn(user);
        when(taskRepository.save(any(Task.class))).thenReturn(task);

        taskService.updateTask(1L, req);

        // activity should be saved for the status change
        verify(activityRepository, atLeastOnce()).save(any());
    }

    @Test
    void deleteTask_notFound_throwsException() {
        when(taskRepository.existsById(99L)).thenReturn(false);

        assertThatThrownBy(() -> taskService.deleteTask(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    void isOverdue_returnsTrue_whenPastDueAndNotDone() {
        Task overdueTask = Task.builder()
                .id(2L).title("Overdue").status(TaskStatus.OPEN)
                .priority(TaskPriority.HIGH).project(project)
                .dueDate(LocalDate.now().minusDays(3))
                .build();

        assertThat(overdueTask.isOverdue()).isTrue();
    }

    @Test
    void isOverdue_returnsFalse_whenDone() {
        Task doneTask = Task.builder()
                .id(3L).title("Done").status(TaskStatus.DONE)
                .priority(TaskPriority.LOW).project(project)
                .dueDate(LocalDate.now().minusDays(1))
                .build();

        assertThat(doneTask.isOverdue()).isFalse();
    }
}

package com.taskmanager.repository;

import com.taskmanager.entity.Task;
import com.taskmanager.enums.TaskPriority;
import com.taskmanager.enums.TaskStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {

    // By project
    Page<Task> findByProjectId(Long projectId, Pageable pageable);

    // By assigned user
    Page<Task> findByAssignedUserId(Long userId, Pageable pageable);

    // By status
    Page<Task> findByStatus(TaskStatus status, Pageable pageable);

    // By project and status
    Page<Task> findByProjectIdAndStatus(Long projectId, TaskStatus status, Pageable pageable);

    // By project and priority
    Page<Task> findByProjectIdAndPriority(Long projectId, TaskPriority priority, Pageable pageable);

    // By project and assigned user
    Page<Task> findByProjectIdAndAssignedUserId(Long projectId, Long userId, Pageable pageable);

    // Full-text keyword search within a project
    @Query("SELECT t FROM Task t WHERE t.project.id = :projectId " +
           "AND (LOWER(t.title) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "OR LOWER(t.description) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<Task> searchByKeywordInProject(@Param("projectId") Long projectId,
                                        @Param("keyword") String keyword,
                                        Pageable pageable);

    // Global keyword search
    @Query("SELECT t FROM Task t WHERE LOWER(t.title) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "OR LOWER(t.description) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    Page<Task> searchByKeyword(@Param("keyword") String keyword, Pageable pageable);

    // Advanced filter
    @Query("SELECT t FROM Task t WHERE " +
           "(:projectId IS NULL OR t.project.id = :projectId) " +
           "AND (:userId IS NULL OR t.assignedUser.id = :userId) " +
           "AND (:status IS NULL OR t.status = :status) " +
           "AND (:priority IS NULL OR t.priority = :priority) " +
           "AND (:keyword IS NULL OR LOWER(t.title) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "     OR LOWER(t.description) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<Task> findWithFilters(@Param("projectId") Long projectId,
                               @Param("userId") Long userId,
                               @Param("status") TaskStatus status,
                               @Param("priority") TaskPriority priority,
                               @Param("keyword") String keyword,
                               Pageable pageable);

    // Overdue tasks
    @Query("SELECT t FROM Task t WHERE t.dueDate < :today AND t.status != 'DONE'")
    List<Task> findOverdueTasks(@Param("today") LocalDate today);

    // Overdue tasks by project
    @Query("SELECT t FROM Task t WHERE t.project.id = :projectId " +
           "AND t.dueDate < :today AND t.status != 'DONE'")
    List<Task> findOverdueTasksByProject(@Param("projectId") Long projectId,
                                         @Param("today") LocalDate today);

    // Count by project
    long countByProjectId(Long projectId);

    long countByProjectIdAndStatus(Long projectId, TaskStatus status);

    long countByAssignedUserId(Long userId);

    // Dashboard: total completed globally
    long countByStatus(TaskStatus status);
}

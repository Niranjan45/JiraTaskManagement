package com.taskmanager.enums;

public enum UserRole {
    ADMIN,
    PROJECT_MANAGER,
    DEVELOPER,
    TESTER,
    VIEWER
}

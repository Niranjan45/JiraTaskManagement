package com.taskmanager.controller;

import com.taskmanager.dto.request.AddCommentRequest;
import com.taskmanager.dto.request.CreateTaskRequest;
import com.taskmanager.dto.request.TaskFilterRequest;
import com.taskmanager.dto.request.UpdateTaskRequest;
import com.taskmanager.dto.response.*;
import com.taskmanager.enums.TaskPriority;
import com.taskmanager.enums.TaskStatus;
import com.taskmanager.service.TaskService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tasks")
@RequiredArgsConstructor
@Tag(name = "Task Management", description = "APIs for managing tasks")
public class TaskController {

    private final TaskService taskService;

  
    @PostMapping
    @Operation(summary = "Create a new task")
    public ResponseEntity<ApiResponse<TaskResponse>> createTask(
            @Valid @RequestBody CreateTaskRequest request) {
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success("Task created successfully", taskService.createTask(request)));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get task by ID")
    public ResponseEntity<ApiResponse<TaskResponse>> getTask(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(taskService.getTaskById(id)));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update task details, status, priority, or assignee")
    public ResponseEntity<ApiResponse<TaskResponse>> updateTask(
            @PathVariable Long id,
            @Valid @RequestBody UpdateTaskRequest request) {
        return ResponseEntity.ok(
                ApiResponse.success("Task updated successfully", taskService.updateTask(id, request)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a task")
    public ResponseEntity<ApiResponse<Void>> deleteTask(@PathVariable Long id) {
        taskService.deleteTask(id);
        return ResponseEntity.ok(ApiResponse.success("Task deleted successfully", null));
    }

    @GetMapping("/project/{projectId}")
    @Operation(summary = "Fetch tasks by project (paginated)")
    public ResponseEntity<ApiResponse<Page<TaskResponse>>> getTasksByProject(
            @PathVariable Long projectId,
            @PageableDefault(size = 10, sort = "createdAt") Pageable pageable) {
        return ResponseEntity.ok(
                ApiResponse.success(taskService.getTasksByProject(projectId, pageable)));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Fetch tasks assigned to a user (paginated)")
    public ResponseEntity<ApiResponse<Page<TaskResponse>>> getTasksByUser(
            @PathVariable Long userId,
            @PageableDefault(size = 10, sort = "createdAt") Pageable pageable) {
        return ResponseEntity.ok(
                ApiResponse.success(taskService.getTasksByUser(userId, pageable)));
    }

    @GetMapping("/filter")
    @Operation(summary = "Filter tasks by project, user, status, priority, or keyword")
    public ResponseEntity<ApiResponse<Page<TaskResponse>>> filterTasks(
            @RequestParam(required = false) Long projectId,
            @RequestParam(required = false) Long userId,
            @RequestParam(required = false) TaskStatus status,
            @RequestParam(required = false) TaskPriority priority,
            @RequestParam(required = false) String keyword,
            @PageableDefault(size = 10) Pageable pageable) {

        TaskFilterRequest filter = new TaskFilterRequest();
        filter.setProjectId(projectId);
        filter.setAssignedUserId(userId);
        filter.setStatus(status);
        filter.setPriority(priority);
        filter.setKeyword(keyword);

        return ResponseEntity.ok(ApiResponse.success(taskService.filterTasks(filter, pageable)));
    }

    
    @GetMapping("/overdue")
    @Operation(summary = "Get all overdue tasks")
    public ResponseEntity<ApiResponse<List<TaskResponse>>> getOverdueTasks() {
        return ResponseEntity.ok(ApiResponse.success(taskService.getOverdueTasks()));
    }

    @GetMapping("/overdue/project/{projectId}")
    @Operation(summary = "Get overdue tasks by project")
    public ResponseEntity<ApiResponse<List<TaskResponse>>> getOverdueTasksByProject(
            @PathVariable Long projectId) {
        return ResponseEntity.ok(ApiResponse.success(taskService.getOverdueTasksByProject(projectId)));
    }

   
    @PostMapping("/{taskId}/comments")
    @Operation(summary = "Add a comment to a task")
    public ResponseEntity<ApiResponse<TaskCommentResponse>> addComment(
            @PathVariable Long taskId,
            @Valid @RequestBody AddCommentRequest request) {
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success("Comment added", taskService.addComment(taskId, request)));
    }

    @GetMapping("/{taskId}/comments")
    @Operation(summary = "Get all comments for a task")
    public ResponseEntity<ApiResponse<Page<TaskCommentResponse>>> getComments(
            @PathVariable Long taskId,
            @PageableDefault(size = 20) Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(taskService.getComments(taskId, pageable)));
    }

  
    @GetMapping("/{taskId}/activities")
    @Operation(summary = "Get audit / activity history of a task")
    public ResponseEntity<ApiResponse<List<TaskActivityResponse>>> getActivity(
            @PathVariable Long taskId) {
        return ResponseEntity.ok(ApiResponse.success(taskService.getTaskActivity(taskId)));
    }

   
    @GetMapping("/dashboard")
    @Operation(summary = "Global dashboard metrics")
    public ResponseEntity<ApiResponse<DashboardResponse>> getDashboard() {
        return ResponseEntity.ok(ApiResponse.success(taskService.getDashboardMetrics()));
    }

    @GetMapping("/dashboard/project/{projectId}")
    @Operation(summary = "Dashboard metrics for a specific project")
    public ResponseEntity<ApiResponse<DashboardResponse>> getProjectDashboard(
            @PathVariable Long projectId) {
        return ResponseEntity.ok(
                ApiResponse.success(taskService.getDashboardMetricsByProject(projectId)));
    }
}

package com.taskmanager.service;

import com.taskmanager.dto.request.CreateProjectRequest;
import com.taskmanager.dto.request.UpdateProjectRequest;
import com.taskmanager.dto.response.ProjectResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ProjectService {

    ProjectResponse createProject(CreateProjectRequest request);

    ProjectResponse getProjectById(Long id);

    Page<ProjectResponse> getAllProjects(Pageable pageable);

    Page<ProjectResponse> searchProjects(String keyword, Pageable pageable);

    ProjectResponse updateProject(Long id, UpdateProjectRequest request);

    List<ProjectResponse> getProjectsByUser(Long userId);

    void deleteProject(Long id);
}

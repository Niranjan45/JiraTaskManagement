package com.taskmanager.service;

import com.taskmanager.dto.request.CreateUserRequest;
import com.taskmanager.dto.request.UpdateUserRequest;
import com.taskmanager.dto.response.UserResponse;

import java.util.List;

public interface UserService {

    UserResponse createUser(CreateUserRequest request);

    UserResponse getUserById(Long id);

    UserResponse updateUser(Long id, UpdateUserRequest request);

    List<UserResponse> getAllUsers();

    List<UserResponse> searchUsers(String keyword);

    void deleteUser(Long id);
}

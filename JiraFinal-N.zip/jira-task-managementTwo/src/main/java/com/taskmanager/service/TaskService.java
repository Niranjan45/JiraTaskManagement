package com.taskmanager.service;

import com.taskmanager.dto.request.AddCommentRequest;
import com.taskmanager.dto.request.CreateTaskRequest;
import com.taskmanager.dto.request.TaskFilterRequest;
import com.taskmanager.dto.request.UpdateTaskRequest;
import com.taskmanager.dto.response.DashboardResponse;
import com.taskmanager.dto.response.TaskActivityResponse;
import com.taskmanager.dto.response.TaskCommentResponse;
import com.taskmanager.dto.response.TaskResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface TaskService {

    TaskResponse createTask(CreateTaskRequest request);

    TaskResponse getTaskById(Long id);

    TaskResponse updateTask(Long id, UpdateTaskRequest request);

    void deleteTask(Long id);

    Page<TaskResponse> getTasksByProject(Long projectId, Pageable pageable);

    Page<TaskResponse> getTasksByUser(Long userId, Pageable pageable);

    Page<TaskResponse> filterTasks(TaskFilterRequest filter, Pageable pageable);

    TaskCommentResponse addComment(Long taskId, AddCommentRequest request);

    Page<TaskCommentResponse> getComments(Long taskId, Pageable pageable);

    List<TaskActivityResponse> getTaskActivity(Long taskId);

    List<TaskResponse> getOverdueTasks();

    List<TaskResponse> getOverdueTasksByProject(Long projectId);

    DashboardResponse getDashboardMetrics();

    DashboardResponse getDashboardMetricsByProject(Long projectId);
}

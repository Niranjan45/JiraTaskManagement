package com.taskmanager.service.impl;

import com.taskmanager.dto.request.AddCommentRequest;
import com.taskmanager.dto.request.CreateTaskRequest;
import com.taskmanager.dto.request.TaskFilterRequest;
import com.taskmanager.dto.request.UpdateTaskRequest;
import com.taskmanager.dto.response.DashboardResponse;
import com.taskmanager.dto.response.TaskActivityResponse;
import com.taskmanager.dto.response.TaskCommentResponse;
import com.taskmanager.dto.response.TaskResponse;
import com.taskmanager.entity.*;
import com.taskmanager.enums.ActivityType;
import com.taskmanager.enums.TaskStatus;
import com.taskmanager.exception.ResourceNotFoundException;
import com.taskmanager.mapper.TaskActivityMapper;
import com.taskmanager.mapper.TaskCommentMapper;
import com.taskmanager.mapper.UserMapper;
import com.taskmanager.repository.TaskActivityRepository;
import com.taskmanager.repository.TaskCommentRepository;
import com.taskmanager.repository.TaskRepository;
import com.taskmanager.service.TaskService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class TaskServiceImpl implements TaskService {

    private final TaskRepository taskRepository;
    private final TaskCommentRepository commentRepository;
    private final TaskActivityRepository activityRepository;
    private final UserServiceImpl userService;
    private final ProjectServiceImpl projectService;
    private final TaskCommentMapper commentMapper;
    private final TaskActivityMapper activityMapper;
    private final UserMapper userMapper;

    @Override
    public TaskResponse createTask(CreateTaskRequest request) {
        log.info("Creating task '{}' in project {}", request.getTitle(), request.getProjectId());

        Project project = projectService.findProjectOrThrow(request.getProjectId());
        User assignee = request.getAssignedUserId() != null
                ? userService.findUserOrThrow(request.getAssignedUserId())
                : null;

        Task task = Task.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .priority(request.getPriority())
                .project(project)
                .assignedUser(assignee)
                .dueDate(request.getDueDate())
                .build();

        Task saved = taskRepository.save(task);

        // Record creation activity
        saveActivity(saved, ActivityType.TASK_CREATED, null, saved.getStatus().name(),
                project.getCreatedBy());

        log.info("Task created with id: {}", saved.getId());
        return toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public TaskResponse getTaskById(Long id) {
        return toResponse(findTaskOrThrow(id));
    }

    @Override
    public TaskResponse updateTask(Long id, UpdateTaskRequest request) {
        log.info("Updating task id: {}", id);
        Task task = findTaskOrThrow(id);
        User updater = userService.findUserOrThrow(request.getUpdatedById());

        // Audit and update each changed field
        if (request.getTitle() != null && !request.getTitle().equals(task.getTitle())) {
            saveActivity(task, ActivityType.TITLE_CHANGED, task.getTitle(), request.getTitle(), updater);
            task.setTitle(request.getTitle());
        }

        if (request.getDescription() != null && !request.getDescription().equals(task.getDescription())) {
            saveActivity(task, ActivityType.DESCRIPTION_CHANGED,
                    task.getDescription(), request.getDescription(), updater);
            task.setDescription(request.getDescription());
        }

        if (request.getStatus() != null && !request.getStatus().equals(task.getStatus())) {
            saveActivity(task, ActivityType.STATUS_CHANGED,
                    task.getStatus().name(), request.getStatus().name(), updater);
            task.setStatus(request.getStatus());
        }

        if (request.getPriority() != null && !request.getPriority().equals(task.getPriority())) {
            saveActivity(task, ActivityType.PRIORITY_CHANGED,
                    task.getPriority().name(), request.getPriority().name(), updater);
            task.setPriority(request.getPriority());
        }

        if (request.getAssignedUserId() != null) {
            Long currentAssigneeId = task.getAssignedUser() != null ? task.getAssignedUser().getId() : null;
            if (!request.getAssignedUserId().equals(currentAssigneeId)) {
                User newAssignee = userService.findUserOrThrow(request.getAssignedUserId());
                String oldName = task.getAssignedUser() != null ? task.getAssignedUser().getName() : "Unassigned";
                saveActivity(task, ActivityType.ASSIGNEE_CHANGED,
                        oldName, newAssignee.getName(), updater);
                task.setAssignedUser(newAssignee);
            }
        }

        if (request.getDueDate() != null && !request.getDueDate().equals(task.getDueDate())) {
            saveActivity(task, ActivityType.DUE_DATE_CHANGED,
                    task.getDueDate() != null ? task.getDueDate().toString() : "None",
                    request.getDueDate().toString(), updater);
            task.setDueDate(request.getDueDate());
        }

        return toResponse(taskRepository.save(task));
    }

    @Override
    public void deleteTask(Long id) {
        log.info("Deleting task id: {}", id);
        if (!taskRepository.existsById(id)) {
            throw new ResourceNotFoundException("Task", id);
        }
        taskRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TaskResponse> getTasksByProject(Long projectId, Pageable pageable) {
        projectService.findProjectOrThrow(projectId);
        return taskRepository.findByProjectId(projectId, pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TaskResponse> getTasksByUser(Long userId, Pageable pageable) {
        userService.findUserOrThrow(userId);
        return taskRepository.findByAssignedUserId(userId, pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TaskResponse> filterTasks(TaskFilterRequest filter, Pageable pageable) {
        return taskRepository.findWithFilters(
                filter.getProjectId(),
                filter.getAssignedUserId(),
                filter.getStatus(),
                filter.getPriority(),
                filter.getKeyword(),
                pageable
        ).map(this::toResponse);
    }

    @Override
    public TaskCommentResponse addComment(Long taskId, AddCommentRequest request) {
        log.info("Adding comment to task id: {}", taskId);
        Task task = findTaskOrThrow(taskId);
        User user = userService.findUserOrThrow(request.getUserId());

        TaskComment comment = TaskComment.builder()
                .task(task)
                .user(user)
                .commentText(request.getCommentText())
                .build();

        TaskComment saved = commentRepository.save(comment);
        saveActivity(task, ActivityType.COMMENT_ADDED, null,
                "Comment by " + user.getName(), user);

        return commentMapper.toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TaskCommentResponse> getComments(Long taskId, Pageable pageable) {
        findTaskOrThrow(taskId);
        return commentRepository.findByTaskIdOrderByCreatedAtDesc(taskId, pageable)
                .map(commentMapper::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TaskActivityResponse> getTaskActivity(Long taskId) {
        findTaskOrThrow(taskId);
        return activityRepository.findByTaskIdOrderByTimestampDesc(taskId).stream()
                .map(activityMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<TaskResponse> getOverdueTasks() {
        return taskRepository.findOverdueTasks(LocalDate.now()).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<TaskResponse> getOverdueTasksByProject(Long projectId) {
        projectService.findProjectOrThrow(projectId);
        return taskRepository.findOverdueTasksByProject(projectId, LocalDate.now()).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public DashboardResponse getDashboardMetrics() {
        long total = taskRepository.count();
        long done = taskRepository.countByStatus(TaskStatus.DONE);
        long inProgress = taskRepository.countByStatus(TaskStatus.IN_PROGRESS);
        long blocked = taskRepository.countByStatus(TaskStatus.BLOCKED);
        long open = taskRepository.countByStatus(TaskStatus.OPEN);
        long overdue = taskRepository.findOverdueTasks(LocalDate.now()).size();
        double rate = total > 0 ? Math.round((done * 100.0 / total) * 100.0) / 100.0 : 0.0;

        return DashboardResponse.builder()
                .totalTasks(total)
                .completedTasks(done)
                .pendingTasks(open)
                .inProgressTasks(inProgress)
                .blockedTasks(blocked)
                .overdueTasks(overdue)
                .completionRate(rate)
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public DashboardResponse getDashboardMetricsByProject(Long projectId) {
        projectService.findProjectOrThrow(projectId);
        long total = taskRepository.countByProjectId(projectId);
        long done = taskRepository.countByProjectIdAndStatus(projectId, TaskStatus.DONE);
        long inProgress = taskRepository.countByProjectIdAndStatus(projectId, TaskStatus.IN_PROGRESS);
        long blocked = taskRepository.countByProjectIdAndStatus(projectId, TaskStatus.BLOCKED);
        long open = taskRepository.countByProjectIdAndStatus(projectId, TaskStatus.OPEN);
        long overdue = taskRepository.findOverdueTasksByProject(projectId, LocalDate.now()).size();
        double rate = total > 0 ? Math.round((done * 100.0 / total) * 100.0) / 100.0 : 0.0;

        return DashboardResponse.builder()
                .totalTasks(total)
                .completedTasks(done)
                .pendingTasks(open)
                .inProgressTasks(inProgress)
                .blockedTasks(blocked)
                .overdueTasks(overdue)
                .completionRate(rate)
                .build();
    }

    // ── helpers ────────────────────────────────────────────────────────────
    private Task findTaskOrThrow(Long id) {
        return taskRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Task", id));
    }

    private void saveActivity(Task task, ActivityType type,
                              String oldVal, String newVal, User updatedBy) {
        TaskActivity activity = TaskActivity.builder()
                .task(task)
                .activityType(type)
                .oldValue(oldVal)
                .newValue(newVal)
                .updatedBy(updatedBy)
                .build();
        activityRepository.save(activity);
    }

    private TaskResponse toResponse(Task task) {
        TaskResponse res = new TaskResponse();
        res.setId(task.getId());
        res.setTitle(task.getTitle());
        res.setDescription(task.getDescription());
        res.setStatus(task.getStatus());
        res.setPriority(task.getPriority());
        res.setProjectId(task.getProject().getId());
        res.setProjectName(task.getProject().getName());
        res.setDueDate(task.getDueDate());
        res.setOverdue(task.isOverdue());
        res.setCreatedAt(task.getCreatedAt());
        res.setUpdatedAt(task.getUpdatedAt());
        if (task.getAssignedUser() != null) {
            res.setAssignedUser(userMapper.toResponse(task.getAssignedUser()));
        }
        return res;
    }
}

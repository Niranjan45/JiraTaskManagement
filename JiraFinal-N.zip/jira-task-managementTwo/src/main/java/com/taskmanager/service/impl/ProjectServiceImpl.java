package com.taskmanager.service.impl;

import com.taskmanager.dto.request.CreateProjectRequest;
import com.taskmanager.dto.request.UpdateProjectRequest;
import com.taskmanager.dto.response.ProjectResponse;
import com.taskmanager.dto.response.UserResponse;
import com.taskmanager.entity.Project;
import com.taskmanager.entity.User;
import com.taskmanager.enums.TaskStatus;
import com.taskmanager.exception.ResourceNotFoundException;
import com.taskmanager.mapper.UserMapper;
import com.taskmanager.repository.ProjectRepository;
import com.taskmanager.repository.TaskRepository;
import com.taskmanager.service.ProjectService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class ProjectServiceImpl implements ProjectService {

    private final ProjectRepository projectRepository;
    private final TaskRepository taskRepository;
    private final UserServiceImpl userService;
    private final UserMapper userMapper;

    @Override
    public ProjectResponse createProject(CreateProjectRequest request) {
        log.info("Creating project: {}", request.getName());
        User creator = userService.findUserOrThrow(request.getCreatedById());
        Project project = Project.builder()
                .name(request.getName())
                .description(request.getDescription())
                .createdBy(creator)
                .build();
        Project saved = projectRepository.save(project);
        log.info("Project created with id: {}", saved.getId());
        return toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public ProjectResponse getProjectById(Long id) {
        return toResponse(findProjectOrThrow(id));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ProjectResponse> getAllProjects(Pageable pageable) {
        return projectRepository.findAll(pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ProjectResponse> searchProjects(String keyword, Pageable pageable) {
        return projectRepository.searchByKeyword(keyword, pageable).map(this::toResponse);
    }

    @Override
    public ProjectResponse updateProject(Long id, UpdateProjectRequest request) {
        log.info("Updating project id: {}", id);
        Project project = findProjectOrThrow(id);
        if (request.getName() != null) project.setName(request.getName());
        if (request.getDescription() != null) project.setDescription(request.getDescription());
        return toResponse(projectRepository.save(project));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProjectResponse> getProjectsByUser(Long userId) {
        userService.findUserOrThrow(userId); // validate user exists
        return projectRepository.findByCreatedById(userId).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public void deleteProject(Long id) {
        log.info("Deleting project id: {}", id);
        if (!projectRepository.existsById(id)) {
            throw new ResourceNotFoundException("Project", id);
        }
        projectRepository.deleteById(id);
    }

    // ── helpers ────────────────────────────────────────────────────────────
    public Project findProjectOrThrow(Long id) {
        return projectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Project", id));
    }

    private ProjectResponse toResponse(Project project) {
        ProjectResponse res = new ProjectResponse();
        res.setId(project.getId());
        res.setName(project.getName());
        res.setDescription(project.getDescription());
        res.setCreatedAt(project.getCreatedAt());

        UserResponse creator = userMapper.toResponse(project.getCreatedBy());
        res.setCreatedBy(creator);

        long total = taskRepository.countByProjectId(project.getId());
        long done = taskRepository.countByProjectIdAndStatus(project.getId(), TaskStatus.DONE);
        double progress = total > 0 ? Math.round((done * 100.0 / total) * 100.0) / 100.0 : 0.0;

        res.setTotalTasks(total);
        res.setCompletedTasks(done);
        res.setProgressPercentage(progress);
        return res;
    }
}

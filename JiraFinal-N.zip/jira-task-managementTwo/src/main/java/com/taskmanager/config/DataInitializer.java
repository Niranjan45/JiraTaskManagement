package com.taskmanager.config;

import com.taskmanager.entity.Project;
import com.taskmanager.entity.Task;
import com.taskmanager.entity.TaskComment;
import com.taskmanager.entity.User;
import com.taskmanager.enums.TaskPriority;
import com.taskmanager.enums.TaskStatus;
import com.taskmanager.enums.UserRole;
import com.taskmanager.repository.ProjectRepository;
import com.taskmanager.repository.TaskCommentRepository;
import com.taskmanager.repository.TaskRepository;
import com.taskmanager.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
@RequiredArgsConstructor
@Slf4j
@Profile("!test") // Don't run during tests
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final ProjectRepository projectRepository;
    private final TaskRepository taskRepository;
    private final TaskCommentRepository commentRepository;

    @Override
    public void run(String... args) {
        if (userRepository.count() > 0) {
            log.info("Sample data already exists, skipping initialization.");
            return;
        }

        log.info("Seeding sample data...");

        // Users
        User admin = userRepository.save(User.builder()
                .name("Alice Admin").email("alice@example.com").role(UserRole.ADMIN).build());
        User pm = userRepository.save(User.builder()
                .name("Bob Manager").email("bob@example.com").role(UserRole.PROJECT_MANAGER).build());
        User dev1 = userRepository.save(User.builder()
                .name("Charlie Dev").email("charlie@example.com").role(UserRole.DEVELOPER).build());
        User dev2 = userRepository.save(User.builder()
                .name("Diana Dev").email("diana@example.com").role(UserRole.DEVELOPER).build());
        User tester = userRepository.save(User.builder()
                .name("Eve Tester").email("eve@example.com").role(UserRole.TESTER).build());

        // Project 1
        Project p1 = projectRepository.save(Project.builder()
                .name("E-Commerce Platform")
                .description("Build a scalable e-commerce platform with microservices.")
                .createdBy(pm)
                .build());

        // Project 2
        Project p2 = projectRepository.save(Project.builder()
                .name("Mobile Banking App")
                .description("Cross-platform mobile banking application.")
                .createdBy(admin)
                .build());

        // Tasks for Project 1
        Task t1 = taskRepository.save(Task.builder()
                .title("Design database schema")
                .description("Create ERD and database schema for product, order, and user tables.")
                .status(TaskStatus.DONE)
                .priority(TaskPriority.HIGH)
                .project(p1).assignedUser(dev1)
                .dueDate(LocalDate.now().minusDays(5))
                .build());

        Task t2 = taskRepository.save(Task.builder()
                .title("Implement product catalog API")
                .description("REST API for CRUD operations on the product catalog.")
                .status(TaskStatus.IN_PROGRESS)
                .priority(TaskPriority.HIGH)
                .project(p1).assignedUser(dev1)
                .dueDate(LocalDate.now().plusDays(3))
                .build());

        Task t3 = taskRepository.save(Task.builder()
                .title("Shopping cart service")
                .description("Implement add/remove/update cart logic with Redis cache.")
                .status(TaskStatus.OPEN)
                .priority(TaskPriority.MEDIUM)
                .project(p1).assignedUser(dev2)
                .dueDate(LocalDate.now().plusDays(7))
                .build());

        Task t4 = taskRepository.save(Task.builder()
                .title("Payment gateway integration")
                .description("Integrate Stripe for payment processing.")
                .status(TaskStatus.BLOCKED)
                .priority(TaskPriority.CRITICAL)
                .project(p1).assignedUser(dev2)
                .dueDate(LocalDate.now().plusDays(10))
                .build());

        Task t5 = taskRepository.save(Task.builder()
                .title("Write integration tests for catalog API")
                .description("Cover all edge cases for product catalog endpoints.")
                .status(TaskStatus.OPEN)
                .priority(TaskPriority.MEDIUM)
                .project(p1).assignedUser(tester)
                .dueDate(LocalDate.now().plusDays(5))
                .build());

        // Tasks for Project 2
        Task t6 = taskRepository.save(Task.builder()
                .title("Authentication module")
                .description("Implement biometric and PIN-based authentication.")
                .status(TaskStatus.IN_PROGRESS)
                .priority(TaskPriority.CRITICAL)
                .project(p2).assignedUser(dev1)
                .dueDate(LocalDate.now().plusDays(2))
                .build());

        Task t7 = taskRepository.save(Task.builder()
                .title("Fund transfer API")
                .description("NEFT, RTGS, IMPS transfer endpoints with transaction history.")
                .status(TaskStatus.OPEN)
                .priority(TaskPriority.HIGH)
                .project(p2).assignedUser(dev2)
                .dueDate(LocalDate.now().plusDays(14))
                .build());

        // Sample comments
        commentRepository.save(TaskComment.builder()
                .task(t2).user(pm)
                .commentText("Please ensure the API supports filtering by category and price range.")
                .build());
        commentRepository.save(TaskComment.builder()
                .task(t2).user(dev1)
                .commentText("Understood. Will also add pagination and sorting support.")
                .build());
        commentRepository.save(TaskComment.builder()
                .task(t4).user(pm)
                .commentText("Blocked because the Stripe test credentials haven't been shared yet.")
                .build());

        log.info("Sample data seeded successfully. Users: 5, Projects: 2, Tasks: 7, Comments: 3");
    }
}

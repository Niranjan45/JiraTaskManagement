package com.taskmanager.config;

import com.taskmanager.mapper.TaskActivityMapper;
import com.taskmanager.mapper.TaskCommentMapper;
import com.taskmanager.mapper.UserMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class MapperConfig {

    @Bean
    @Primary
    public UserMapper userMapper() {
        return new UserMapper();
    }

    @Bean
    @Primary
    public TaskCommentMapper taskCommentMapper(UserMapper userMapper) {
        return new TaskCommentMapper(userMapper);
    }

    @Bean
    @Primary
    public TaskActivityMapper taskActivityMapper(UserMapper userMapper) {
        return new TaskActivityMapper(userMapper);
    }
}

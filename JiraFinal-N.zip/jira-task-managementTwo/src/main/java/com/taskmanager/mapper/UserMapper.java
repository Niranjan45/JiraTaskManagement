package com.taskmanager.mapper;

import com.taskmanager.dto.request.CreateUserRequest;
import com.taskmanager.dto.response.UserResponse;
import com.taskmanager.entity.User;
import org.springframework.stereotype.Component;

@Component
public class UserMapper {

    public UserResponse toResponse(User user) {
        if (user == null) return null;
        UserResponse res = new UserResponse();
        res.setId(user.getId());
        res.setName(user.getName());
        res.setEmail(user.getEmail());
        res.setRole(user.getRole());
        res.setCreatedAt(user.getCreatedAt());
        return res;
    }

    public User toEntity(CreateUserRequest request) {
        if (request == null) return null;
        return User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .role(request.getRole())
                .build();
    }

    public void updateEntity(CreateUserRequest request, User user) {
        if (request == null || user == null) return;
        if (request.getName()  != null) user.setName(request.getName());
        if (request.getEmail() != null) user.setEmail(request.getEmail());
        if (request.getRole()  != null) user.setRole(request.getRole());
    }
}

package com.taskmanager.mapper;

import com.taskmanager.dto.response.TaskActivityResponse;
import com.taskmanager.entity.TaskActivity;
import org.springframework.stereotype.Component;

@Component
public class TaskActivityMapper {

    private final UserMapper userMapper;

    public TaskActivityMapper(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    public TaskActivityResponse toResponse(TaskActivity activity) {
        if (activity == null) return null;
        TaskActivityResponse res = new TaskActivityResponse();
        res.setId(activity.getId());
        res.setTaskId(activity.getTask().getId());
        res.setActivityType(activity.getActivityType());
        res.setOldValue(activity.getOldValue());
        res.setNewValue(activity.getNewValue());
        res.setUpdatedBy(userMapper.toResponse(activity.getUpdatedBy()));
        res.setTimestamp(activity.getTimestamp());
        return res;
    }
}

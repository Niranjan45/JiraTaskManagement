package com.taskmanager.mapper;

import com.taskmanager.dto.response.TaskCommentResponse;
import com.taskmanager.entity.TaskComment;
import org.springframework.stereotype.Component;

@Component
public class TaskCommentMapper {

    private final UserMapper userMapper;

    public TaskCommentMapper(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    public TaskCommentResponse toResponse(TaskComment comment) {
        if (comment == null) return null;
        TaskCommentResponse res = new TaskCommentResponse();
        res.setId(comment.getId());
        res.setTaskId(comment.getTask().getId());
        res.setUser(userMapper.toResponse(comment.getUser()));
        res.setCommentText(comment.getCommentText());
        res.setCreatedAt(comment.getCreatedAt());
        return res;
    }
}

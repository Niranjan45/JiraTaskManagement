package com.taskmanager.dto.request;

import com.taskmanager.enums.TaskPriority;
import com.taskmanager.enums.TaskStatus;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.LocalDate;

@Data
public class UpdateTaskRequest {

    @Size(min = 2, max = 300, message = "Title must be between 2 and 300 characters")
    private String title;

    @Size(max = 5000, message = "Description can be at most 5000 characters")
    private String description;

    private TaskStatus status;

    private TaskPriority priority;

    private Long assignedUserId;

    private LocalDate dueDate;

    /** The ID of the user performing the update — required for audit history */
    @NotNull(message = "updatedById is required")
    private Long updatedById;
}

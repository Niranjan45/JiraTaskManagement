package com.taskmanager.dto.request;

import com.taskmanager.enums.TaskPriority;
import com.taskmanager.enums.TaskStatus;
import lombok.Data;

@Data
public class TaskFilterRequest {
    private Long projectId;
    private Long assignedUserId;
    private TaskStatus status;
    private TaskPriority priority;
    private String keyword;
}

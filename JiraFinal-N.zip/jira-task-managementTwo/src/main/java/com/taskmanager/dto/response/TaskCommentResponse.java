package com.taskmanager.dto.response;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class TaskCommentResponse {
    private Long id;
    private Long taskId;
    private UserResponse user;
    private String commentText;
    private LocalDateTime createdAt;
}

package com.taskmanager.dto.request;

import com.taskmanager.enums.TaskPriority;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.LocalDate;

@Data
public class CreateTaskRequest {

    @NotBlank(message = "Task title is required")
    @Size(min = 2, max = 300, message = "Title must be between 2 and 300 characters")
    private String title;

    @Size(max = 5000, message = "Description can be at most 5000 characters")
    private String description;

    private TaskPriority priority = TaskPriority.MEDIUM;

    @NotNull(message = "Project ID is required")
    private Long projectId;

    private Long assignedUserId;

    private LocalDate dueDate;
}

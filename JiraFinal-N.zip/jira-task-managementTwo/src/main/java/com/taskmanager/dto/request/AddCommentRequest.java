package com.taskmanager.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class AddCommentRequest {

    @NotNull(message = "User ID is required")
    private Long userId;

    @NotBlank(message = "Comment text is required")
    @Size(min = 1, max = 3000, message = "Comment must be between 1 and 3000 characters")
    private String commentText;
}
